class Weapon:
    def __init__(self, name, dmg):
        self.name = name
        self.dmg = dmg

